package  x_o;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author Khaled
 */
public class x_o {
    public static ArrayList<Integer> num=new ArrayList<Integer>();
    
     public static JButton[] arr = new JButton[9];
      static JButton b1,b2,b3,b4,b5,b6,b7,b8,b9,retryButton;
       static int run=0;
      static  JFrame f;
    public static void main(String[] args) {
           
    f=new JFrame("X-O Game");  
    b1=new JButton();  
    arr[0]=b1;
    b1.setBounds(50,100,130,130);  
    f.add(b1); 
    
      b2=new JButton();  
          arr[1]=b2;

    b2.setBounds(200,100,130,130);  
    f.add(b2); 
    
      b3=new JButton();  
          arr[2]=b3;

    b3.setBounds(350,100,130,130);  
    f.add(b3); 
    
      b4=new JButton();  
          arr[3]=b4;

    b4.setBounds(50,250,130,130);  
    f.add(b4); 
    
      b5=new JButton(); 
          arr[4]=b5;

    b5.setBounds(200,250,130,130);  
    f.add(b5); 
    
      b6=new JButton(); 
          arr[5]=b6;

    b6.setBounds(350,250,130,130);  
    f.add(b6); 
    
      b7=new JButton();  
          arr[6]=b7;

    b7.setBounds(50,400,130,130);  
    f.add(b7); 
    
      b8=new JButton();  
          arr[7]=b8;

    b8.setBounds(200,400,130,130);  
    f.add(b8); 
    
      b9=new JButton();  
          arr[8]=b9;

    b9.setBounds(350,400,130,130);  
    f.add(b9); 
    retryButton =new JButton("New Game");
    f.add(retryButton);
    retryButton.setBounds(50, 20, 100, 30);
    f.setSize(700,700);  
    f.setLayout(null);  
    f.setVisible(true);   
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    b1.addActionListener(new press1());
    b2.addActionListener(new press2());
    b3.addActionListener(new press3());
    b4.addActionListener(new press4());
    b5.addActionListener(new press5());
    b6.addActionListener(new press6());
    b7.addActionListener(new press7());
    b8.addActionListener(new press8());
    b9.addActionListener(new press9());
    retryButton.addActionListener(new retry());
   
        
    }
  
    
            
    public static void computerTurn(){
        while(true){ 
            if(num.size()==9){
            break;
            }
                Random r = new Random();
                int random=r.nextInt(9);
               if(!num.contains(random)){
               num.add(random);
               arr[random].setText("O");
               break;
              }
            }
    }
    
    public static void checkWin(){
    if((b1.getText().equals("X")&&b4.getText().equals("X")&&b7.getText().equals("X"))||(b1.getText().equals("X")&&b2.getText().equals("X")&&b3.getText().equals("X"))||(b3.getText().equals("X")&&b6.getText().equals("X")&&b9.getText().equals("X"))||(b9.getText().equals("X")&&b8.getText().equals("X")&&b7.getText().equals("X"))||(b1.getText().equals("X")&&b5.getText().equals("X")&&b9.getText().equals("X"))||(b3.getText().equals("X")&&b5.getText().equals("X")&&b7.getText().equals("X"))||(b2.getText().equals("X")&&b5.getText().equals("X")&&b8.getText().equals("X"))||(b6.getText().equals("X")&&b5.getText().equals("X")&&b4.getText().equals("X"))){
       JOptionPane.showMessageDialog(null, "You Win");    
    } 
    }
    public static void checkWiny(){
    
        
        if((b1.getText().equals("O")&&b4.getText().equals("O")&&b7.getText().equals("O"))||(b1.getText().equals("O")&&b2.getText().equals("O")&&b3.getText().equals("O"))||(b3.getText().equals("O")&&b6.getText().equals("O")&&b9.getText().equals("O"))||(b9.getText().equals("O")&&b8.getText().equals("O")&&b7.getText().equals("O"))||(b1.getText().equals("O")&&b5.getText().equals("O")&&b9.getText().equals("O"))||(b3.getText().equals("O")&&b5.getText().equals("O")&&b7.getText().equals("O"))||(b2.getText().equals("O")&&b5.getText().equals("O")&&b8.getText().equals("O"))||(b6.getText().equals("O")&&b5.getText().equals("O")&&b4.getText().equals("O"))){
        JOptionPane.showMessageDialog(null, "You lose");
    }
    
    }
      private  static class press1 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            if(arr[0].getText().equals("")){
            arr[0].setText("X");
            num.add(0);
            checkWin();
            
            computerTurn();
            checkWiny();
        }
        
        
        }
       
   }
      
      private static  class press2 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
           if(arr[1].getText().equals("")){
            arr[1].setText("X");
            num.add(1);
            checkWin();
            
            computerTurn();
            checkWiny();
        }
        
        }
      }
      
      private   static class press3 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            if(arr[2].getText().equals("")){
            arr[2].setText("X");
            num.add(2);
            checkWin();
            computerTurn();
            checkWiny();


        }
        
        }
      }
      
      private static  class press4 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
           if(arr[3].getText().equals("")){
            arr[3].setText("X");
            num.add(3);
            checkWin();
            computerTurn();
            checkWiny();


        }
        
        }
      }
      
      private static class press5 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
            if(arr[4].getText().equals("")){
            arr[4].setText("X");
            num.add(4);
            checkWin();
            computerTurn();
            checkWiny();


        }
        
        }
      }
      
      private static class press6 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
             if(arr[5].getText().equals("")){
            arr[5].setText("X");
            num.add(5);
            checkWin();
            computerTurn();
            checkWiny();


        }
        
        }
      }
      
      private static class press7 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
             if(arr[6].getText().equals("")){
            arr[6].setText("X");
            num.add(6);
            checkWin();
            computerTurn();
            checkWiny();


        }
        
        }
      }
      
      private static class press8 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
              if(arr[7].getText().equals("")){
            arr[7].setText("X");
            num.add(7);
            checkWin();
            computerTurn();
            checkWiny();


        }
        
        }
      }
      
      private static class press9 implements ActionListener{
        public void actionPerformed(ActionEvent e) {
             if(arr[8].getText().equals("")){
            arr[8].setText("X");
            num.add(8);
            checkWin();
            
            computerTurn();
            checkWiny();


        }
        
        } 
      }
      
      private static class retry implements ActionListener{
        public void actionPerformed(ActionEvent e) {
              f.dispose();
            
        }
      }
      
 }
       